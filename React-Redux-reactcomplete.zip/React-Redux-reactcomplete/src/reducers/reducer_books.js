export default function(){

    return [

{title: ' AngularJS Book', pages: 101},
{title: ' NodeJS Book', pages: 141},
{title: ' ReactJS Book', pages: 121},
{title: ' Mean Stack Book', pages: 156}

    ]
}