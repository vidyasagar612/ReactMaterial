import React, { Component } from 'react'
 import ListItem from './ListItem'
 import Perf from 'react-addons-perf'


function arrayGenerator(length) {
  return Array.apply(null, { length: length }).map(Number.call, Number)
}

class App2 extends Component {
  constructor(props) {
    super(props)
    this.state = {
      multiplier: 1
    }
  }
  componentDidUpdate() {
    Perf.stop()
    Perf.printInclusive()
    Perf.printWasted()
  }
  resetMultiplier() {
	      Perf.start()

    this.setState({ multiplier: 2 })
  }

  render() {
    return (
      <div className="App">
        <button onClick={this.resetMultiplier.bind(this)}>Click Me</button>
        <ul>
          {
            arrayGenerator(5000).map(i => {
              return <ListItem key={i} text={i}/>
            })
          }
          {
            arrayGenerator(5000).map(i => {
              return <ListItem key={i} text={i + this.state.multiplier}/>
            })
          }
        </ul>
      </div>
    );
  }
}

export default App2