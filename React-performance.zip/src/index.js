import React from 'react';
import ReactDOM from 'react-dom';
  
import App2 from './components/app2';
 
 
ReactDOM.render(
     <App2 />
   
  , document.querySelector('.container'));
