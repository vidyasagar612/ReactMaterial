# Blog API

Run this locally if you want to have your own blog server.

Setup
-----
In the project root, run the following:
```
bundle
rake db:create
rake db:migrate
rails s
```

And away you go!
